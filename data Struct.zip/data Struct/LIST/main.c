#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next;
    int val;
}NODE;

typedef struct list{
    NODE *node;
}LIST;

void ini_bez(LIST *list){
    list->node = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add_bez(LIST *list, int val){
    NODE *tmp = ML;
    tmp->val = val;
    tmp->next = NULL;
    if(isEmpty(list->node)){
        list->node = tmp;
    }else{
        NODE *ind = list->node;
        while(ind->next){
            ind = ind->next;
        }
        ind->next = tmp;
    }
}

void show_bez(LIST list){
    while(list.node){
        printf("%d->", list.node->val);
        list.node = list.node->next;
    }
}

void ini_smer(LIST *list){
    list->node = ML;
    list->node->next = NULL;
}

void add_smer(LIST *list, int val){
    NODE *n = ML;
    n->next = ML;
    n->val = val;
    n->next->next = NULL;
    if(isEmpty(list->node->next)){
        list->node = n;
    }else{
        NODE *index = list->node;
        while(index->next->next){
            index = index->next;
        }
        index->next = n;
    }
}

void show_smer(LIST l1){
    NODE *ind = l1.node;
    while(ind->next){
        printf("%d->", ind->val);
        ind = ind->next;
    }
    printf("NULL\n");
}

int main()
{
    LIST list;
    ini_bez(&list);
    for(int i = 0; i < 15; i++)
        add_bez(&list, i);
    show_bez(list);

    printf("\n");
    LIST l1;
    ini_smer(&l1);
    for(int i = 0; i < 15; i++){
        add_smer(&l1, i);
    }

    show_smer(l1);
    return 0;
}
