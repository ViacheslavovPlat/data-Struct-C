#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next;
    int val;
}NODE;

typedef struct{
    NODE *start, *index, *end;
}LIST;

void ini(LIST *list){
    list->start = list->end = list->index = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add(LIST *list, int val){
    if(isEmpty(list->start)){
        list->start = ML;
        list->end = list->index = list->start;
        list->start->val = val;
        list->start->next = NULL;
    }else{
        list->end->next = ML;
        list->end = list->end->next;
        list->end->val = val;
        list->end->next = NULL;
        list->index = list->end;
    }
}

void step_forward(LIST *list){
    if(!isEmpty(list->end)){
        if(list->index != list->end)
            list->index = list->index->next;
        else
            printf("index is already at the end\n");
    }
}

void step_backwards(LIST *list){
    if(!isEmpty(list->start)){
        if(list->index != list->start){
            NODE *tmp = list->start;
            while(tmp->next != list->index){
                tmp = tmp->next;
            }
            list->index = tmp;
        } else {
            printf("index is alraedy at the start\n");
        }
    }
}

void jmp_start(LIST *list){
    list->index = list->start;
}

void jmp_end(LIST *list){
    list->index = list->end;
}

void pop(LIST *list){
    if(!isEmpty(list->start)){
        NODE *tmp;
        if(list->index == list->start){
            tmp = list->index;
            list->start = list->index = list->start->next;
            if(list->start == NULL){
                list->end = NULL;
            }
            free(tmp);
        }else if(list->index == list->end){
            tmp = list->start;
            while(tmp->next != list->end){
                tmp = tmp->next;
            }
            list->end = tmp;
            list->end->next = NULL;
            list->index = list->end;
            tmp = tmp->next;
            free(tmp);
        }else{
            tmp = list->start;
            while(tmp->next != list->index){
                tmp = tmp->next;
            }
            tmp->next = list->index->next;
            free(list->index);
            list->index = tmp;
        }
    }
}

void show(LIST list){
    NODE *tmp = list.start;
    do{
        printf("%d->", tmp->val);
        tmp = tmp->next;
    }while(tmp);
    printf("end\n");
}

int main()
{
    LIST list;
    ini(&list);
    for(int i = 0; i < 15; i++){
        add(&list, i);
    }

    show(list);
    jmp_end(&list);
    pop(&list);
    show(list);
    jmp_start(&list);
    pop(&list);
    show(list);
    step_forward(&list);
    step_forward(&list);
    step_forward(&list);
    pop(&list);
    show(list);
    return 0;
}
