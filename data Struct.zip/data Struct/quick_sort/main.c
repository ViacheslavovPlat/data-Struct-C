#include <stdio.h>
#include <stdlib.h>

int unsorted[] = {7,3,4,8,6,1,9,2,5};

int size_arr = sizeof(unsorted)/sizeof(int);

int main()
{
    print_arr(unsorted, size_arr);
    quick_sort(unsorted, size_arr);
    print_arr(unsorted, size_arr);
    return 0;
}

void quick_sort(int arr[], int size){
    if(size <= 1)return;

    int pivot = size - 1;
    int pivot_val = arr[pivot];

    int A[size];
    int B[size];
    int E[size];

    int j = 0, k = 0, i, e = 0;
    for(i = 0; i < size; i++){
        if(arr[i] < pivot_val){
            A[j++] = arr[i];
        }else if(arr[i] > pivot_val){
            B[k++] = arr[i];
        }else{
            E[e++] = arr[i];
        }
    }
    quick_sort(A, j);
    quick_sort(B, k);
    i = 0;
    for(int m = 0; m < j; m++) arr[i++] = A[m];
    for(int m = 0; m < e; m++) arr[i++] = E[m];
    for(int m = 0; m < k; m++) arr[i++] = B[m];
}

void print_arr(int arr[], int size){
    for(int i = 0; i < size ; i++)
        printf("[%d]", arr[i]);
        printf("\n");
}
