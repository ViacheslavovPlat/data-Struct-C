#include <stdio.h>
#include <stdlib.h>

#define N 8

char board[N][N];

int dx[8] = { 2,  1, -1, -2, -2, -1,  1,  2 };
int dy[8] = { 1,  2,  2,  1, -1, -2, -2, -1 };

int find(int x, int y, int step){
    board[x][y] = 'k';
    if(step == N*N){
        return 1;
    }

    for(int i = 0; i < 8; i++){
        int new_x = x + dx[i];
        int new_y = y + dy[i];
        if(new_x >= 0 && new_x < N && new_y >= 0 && new_y < N){
            if(board[new_x][new_y] == '0'){
                if(find(new_x,new_y,step+1))
                    return 1;

                board[new_x][new_y] = '0';
                //step--;
            }
        }
    }
    board[x][y] = '0';
    return 0;
}

int main()
{
    for(int i = 0; i < N; i++)
        for(int j = 0; j < N; j++)
            board[i][j] = '0';

    find(0,0,1);

    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            printf("%c ", board[i][j]);
        }
        printf("\n");
    }
    return 0;
}
