#include <stdio.h>
#include <stdlib.h>

#define ml (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next;
    int val;
}NODE;

void add(NODE **n, int val){
    NODE *tmp = *n;
    while(tmp)
        tmp = tmp->next;
    tmp->next = ml;
    tmp->val;
    tmp->next = NULL;
}

int main()
{
    NODE *n = ml;
    n->val = -1;
    n->next = NULL;

    for(int i = 0; i < 11; i++)
        add(&n, i);

    while(n){
        printf("%d->", n->val);
        n = n->next;
    }
    return 0;
}
