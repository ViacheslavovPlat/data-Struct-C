#include <stdio.h>
#include <stdlib.h>

#define ML(n) malloc(sizeof(int) * (n))

int* mergesort(int *, int);
int* merge(int *, int *, int, int);

int main()
{
    int unsroted[] = {2,7,5,8,1,9,3,4,6};
    //int unsroted[] = {2,3,4,1};
    int size = sizeof(unsroted)/ sizeof(unsroted[0]);

    for(int i = 0; i < size; i++){
        printf("[%d]", unsroted[i]);
    }
    printf("\n");

    //int *sorted = mergesort(unsroted, size);
    int sorted[size];
    for(int i = 0; i < size; i++){
        sorted[i] = unsroted[i];
    }
    printf("Size:%d\n", size);
    heapSort(sorted, size);

    for(int i = 0; i < size; i++){
        printf("[%d]", sorted[i]);
    }
    return 0;
}

int* mergesort(int *arr, int size){
    if(size == 1){
        int *sorted = ML(1);
        sorted[0] = arr[0];
        return sorted;
    }

    int sizeA = size/2;
    int sizeB = size - sizeA;

    int *A = ML(sizeA);
    int *B = ML(sizeB);

    for(int i = 0; i < sizeA; i++){
        A[i] = arr[i];
    }

    for(int i = sizeA; i < size; i++){
        B[i-sizeA] = arr[i];
    }

    int *sortedA= mergesort(A, sizeA);
    int *sortedB = mergesort(B, sizeB);
    free(A);
    free(B);

    int *result = merge(sortedA,sortedB,sizeA, sizeB);
    return result;
}

int* merge(int *A, int *B, int sizeA, int sizeB){
    int size = sizeA + sizeB;
    int *C = ML(sizeA + sizeB);
    int i = 0, j = 0, k = 0;

    while(i < sizeA && j < sizeB){
        if(A[i] <= B[j]){
            C[k++] = A[i++];
        }else{
            C[k++] = B[j++];
        }
    }

    while(i < sizeA){
        C[k++] = A[i++];
    }

    while(j < sizeB){
        C[k++] = B[j++];
    }

    return C;
}

void heapSort(int *arr, int size){
    int i = size/2 - 1;
    while(i >= 0){
        heapify(arr, size, i);
        i--;
    }
    printf("After building max-heap ");
    printArray(arr, size);

    for(i = size-1; i > 0; i--){
        int tmp = arr[0];
        arr[0] = arr[i];
        arr[i] = tmp;
        printf("swap root<->arr[%d]: ", i);
        printArray(arr, size);
        heapify(arr, i, 0);
    }
}

void heapify(int *arr, int size, int i){
    int largest = i;
    int left = 2*i+1;
    int right = 2*i+2;

    if(left >= size && right >= size)
        return;
    if(left < size && arr[left] > arr[largest])
        largest = left;
    if(right < size && arr[right] > arr[largest])
        largest = right;

    if(largest != i){
        int tmp = arr[largest];
        arr[largest] = arr[i];
        arr[i] = tmp;
        printf("  swap in heapify: i=%d, largest=%d -> ", i, largest);
        printArray(arr, size);
        heapify(arr, size, largest);
    }
}

void printArray(int *arr, int size) {
    for (int k = 0; k < size; k++) {
        printf("[%d]", arr[k]);
    }
    printf("\n");
}
