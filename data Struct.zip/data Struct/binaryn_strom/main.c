#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))
#define IS_LETTER(n) ((n >= 'A') && (n <= 'Z'))

typedef struct node{
    struct node *left, *right;
    char morse_sign;
    char letter;
    int val;
}NODE;

void ini(NODE **n, char sign){
    *n = ML;
    (*n)->morse_sign = sign;
    (*n)->left = (*n)->right = NULL;
    (*n)->val = -1;
}

void add_letter(NODE **n, char morse_code[], char lt){
    int i = 0;
    NODE *index = *n;
    while(morse_code[i] != '\0'){
        if(morse_code[i] == '.'){
            if(!index->left){
                ini(&index->left, morse_code[i]);
            }
            index = index->left;
        }else if(morse_code[i] == '-'){
            if(!index->right){
                ini(&index->right, morse_code[i]);
            }
            index = index->right;
        }
        i++;
    }
    index->letter = lt;
}

void add_val(NODE **n, char morse_code[], int val){
    int i = 0;
    NODE *index = *n;
    while(morse_code[i] != '\0'){
        if(morse_code[i] == '.'){
            if(!index->left){
                ini(&index->left, morse_code[i]);
            }
            index = index->left;
        }else if(morse_code[i] == '-'){
            if(!index->right){
                ini(&index->right, morse_code[i]);
            }
            index = index->right;
        }
        i++;
    }
    index->val = val;
}

char print_letter(NODE *bs, char morse_code[]){
    int i = 0;
    while(morse_code[i] != '\0'){
        if(morse_code[i] == '.')
            if(bs->left)
                bs = bs->left;
            else{
                printf("No such letter!\n");
                return '\0';
            }
        else
            if(bs->right)
                bs = bs->right;
            else{
                printf("No such letter!\n");
                return '\0';
            }
        i++;
    }
    return bs->letter;
}

int print_val(NODE *bs, char morse_code[]){
    int i = 0;
    while(morse_code[i] != '\0'){
        if(morse_code[i] == '.')
            if(bs->left)
                bs = bs->left;
            else{
                printf("No such value!\n");
                return -1;
            }
        else
            if(bs->right)
                bs = bs->right;
            else{
                printf("No such value!\n");
                return -1;
            }
        i++;
    }
    return bs->val;
}

void decode_morse(NODE *bin, const char morse_code[]){
    int i = 0, j = 0;
    char code[6];
    while(morse_code[i] != '\0'){
        if(morse_code[i] == ' '){
            code[j] = '\0';
            printf("%c",print_letter(bin,code));
            j = 0;
        }else{
            code[j++] = morse_code[i];
        }
        i++;
    }
    if (j > 0) {
        code[j] = '\0';
        printf("%c", print_letter(bin, code));
    }

    printf("\n");
}

int main()
{
    NODE *bin_strom;
    ini(&bin_strom, ' ');

    FILE *f = fopen("morse_code.txt", "r");

    char buff[6];
    char sc;
    int val = sc - '0';
    while(fscanf(f, " %c %s", &sc, buff) == 2){
        if(IS_LETTER(sc)){
            add_letter(&bin_strom, buff, sc);
        }else{
            int val = sc;
            add_val(&bin_strom, buff, val);
        }
    }

    //printf("%c\n",print_letter(bin_strom, ".-"));
    decode_morse(bin_strom, ".- .--. .--. .-.. .");
    return 0;
}
