#include <stdio.h>
#include <stdlib.h>

#define N 8

int blud[N][N];

int moves[4][2] = { {1,0},
                    {0,1},
                    {-1,0},
                    {0,-1}};

void find(int x, int y){
    if(x == N-1 && y == N-1){
        blud[x][y] = 1;
        printf("Ura\n");
        return;
    }

    blud[x][y] = 1;
    for(int i = 0; i < 4; i++){
        int new_x =x + moves[i][0];
        int new_y =y + moves[i][1];
        if(new_x >= 0 && new_x < N && new_y >= 0 && new_y < N){
            if(blud[new_x][new_y] == 0){
                find(new_x, new_y);
                return;
            }
        }
    }
    blud[x][y] = 0;
}

int main()
{
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            blud[i][j] = 0;
        }
    }

    blud[7][0] = 3;
    blud[6][0] = 3;
    blud[5][0] = 3;
    blud[5][1] = 3;
    blud[5][3] = 3;

    find(0,0);
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            if(blud[i][j])
                printf("%d ", blud[i][j]);
            else
                printf("0 ");
        }
        printf("\n");
    }
    return 0;
}
