#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next, *prev;
    int val;
}NODE;

typedef struct {
    NODE *start, *index, *end;
}LIST;

void ini(LIST *list){
    list->start = list->end = list->index = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add(LIST *list, int val){
    if(isEmpty(list->start)){
        list->start = ML;
        list->start->val = val;
        list->start->prev = NULL;
        list->start->next = NULL;
        list->end = list->index = list->start;
    }else{
        if(list->index == list->end){
            list->end->next = ML;
            list->end->next->val = val;
            list->end->next->next = NULL;
            list->end->next->prev = list->end;
            list->end = list->end->next;
            list->index = list->end;
        }else{
            NODE *tmp = ML;
            tmp->val = val;
            tmp->prev = list->index;
            tmp->next = list->index->next;
            list->index->next->prev = tmp;
            list->index->next = tmp;
            list->index = tmp;
        }
    }
}

void step_forward(LIST *list){
    if(list->index)
        list->index = list->index->next;
    else
        printf("index is already at the end of list\n");
}

void step_backwards(LIST *list){
    if(list->index)
        list->index = list->index->prev;
    else
        printf("idnex is already at the start of list\n");
}

void jmp_start(LIST *list){
    list->index = list->start;
}

void jmp_end(LIST *list){
    list->index = list->end;
}

void show_norm(LIST *list){
    if(!isEmpty(list->start)){
        jmp_start(list);
        while(list->index){
            printf("%d->", list->index->val);
            step_forward(list);
        }
        printf("END\n");
    }
}

void show_revers(LIST *list){
    if(!isEmpty(list->end)){
        jmp_end(list);
        while(list->index){
            printf("%d<-", list->index->val);
            step_backwards(list);
        }
        printf("START\n");
    }
}

int main()
{
    LIST list;
    ini(&list);
    for(int i = 0; i < 15; i++)
        add(&list, i);

    show_norm(&list);
    show_revers(&list);
    return 0;
}
