#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define ELEM_COUNT 12
#define FI 0.6180339887
#define ML (ATOM*)malloc(sizeof(ATOM))

typedef struct {
    char name[20];
    char surname[20];
    int val;
    float fval;
}SC;

typedef struct atom{
    SC sc;
    struct atom *next;
}ATOM;

int getHashTabSize(int n){
    n += (int)(n/3);
    while(!isPrime(n))
        n++;
    return n;
}

int isPrime(int n){
    if(n == 1 || n == 0)
        return 0;
    int lim = sqrt(n);
    for(int i = 2; i <= lim; i++){
        if(n % i == 0)
            return 0;
    }
    return 1;
}

int FloatHash(float n){
    float min = 0, max = 100;
    return ceil(((n - min)/(max - min)) * (getHashTabSize(ELEM_COUNT)-1));
}

int IntHash1(int n){
    float min = 22 , max = 35;
    return ceil((n-min)/(max-min) * (getHashTabSize(ELEM_COUNT)- 1));
}

int IntHash2(int n){
    float max = 35;
    int w = 1;

    while(w < max)
        w <<= 1;
    return ceil((n/(float)w) * (getHashTabSize(ELEM_COUNT) - 1));
}

int IntHash3(int n){
    float pom = n * FI;
    pom -=(int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT)-1));
}

int IntHash4(int n){
    return n % getHashTabSize(ELEM_COUNT);
}

int StrHash1(char *str){
    //'a' = 97 1100001 'A' = 65 1000001 & 00011111
    long long int x = 0;
    int c , i = 1;
    x = str[0] & 31;
    while(str[i] != '\0'){
        x <<= 5;
        c = str[i] & 31;
        x |= c;
        i++;
    }

    long double pom = x * FI;
    pom -=(long long int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT)-1));
}

int StrHash2(char *str){
    int x = 0;
    int c, i = 1;
    x = str[0] & 31;
    while(str[i] != '\0'){
        c = str[i] & 31;
        x = x ^ c;
        i++;
    }
    float pom = x * FI;
    pom -=(int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT) -1));
}

int StrHash3(char *str){
    long long x = 0;
    int i = 1, c;
    x = str[0] & 31;
    while(str[i] != '\0'){
        x <<=1;
        c = str[i] & 31;
        x ^= c;
        i++;
    }
    float pom = x * FI;
    pom -=(long long int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT) - 1));
}

int main()
{
    FILE *f = fopen("sample_data.txt", "r");
    SC sc;
    int tab_size = getHashTabSize(ELEM_COUNT);
    ATOM *hashTable[tab_size];
    int i = 0;
    while(i < tab_size)
        hashTable[i++] = NULL;

    while(fscanf(f,"%s %s %d %f", sc.name, sc.surname, &sc.val, &sc.fval) == 4){
        //printf("%s->#STR:%d %s->#STR:%d %d->#INT:%d %.2f->#F:%d\n", sc.name, StrHash1(sc.name), sc.surname, StrHash1(sc.surname),sc.val, IntHash4(sc.val), sc.fval, FloatHash(sc.fval));
        int pos = StrHash1(sc.name);
        printf("%s %s %d %.2f ->#STR:%d\n", sc.name, sc.surname, sc.val, sc.fval, pos);
        ///linerane zretaz
        ATOM *pom = hashTable[pos];
        ATOM *new_atom = ML;
        new_atom->next = NULL;
        new_atom->sc.fval = sc.fval;
        new_atom->sc.val = sc.val;
        strcpy(new_atom->sc.name,sc.name);
        strcpy(new_atom->sc.surname,sc.surname);
        if(pom){
            while(pom->next)
                pom = pom->next;
            pom->next = new_atom;
        }else{
            hashTable[pos] = new_atom;
        }
    }
    fclose(f);

    for(i = 0; i < tab_size; i++){
        if(hashTable[i]){
            if(hashTable[i]->next){
                ATOM *pom = hashTable[i];
                do{
                    printf("hash [%d] %s %s\n", i, pom->sc.name, pom->sc.surname);
                    pom = pom->next;
                }while(pom);
            }else{
                printf("hash [%d] %s %s\n", i, hashTable[i]->sc.name, hashTable[i]->sc.surname);
            }
        }
    }
    char str[] = "Filip";
    int hash = StrHash1(str);
    ATOM *index = hashTable[hash];
    while((index) && (strcmp(str, index->sc.name) != 0)){
        index = index->next;
    }
    if(!index)
        printf("neni taky to\n");
    else
        printf("nasiel sa %s", index->sc.name);
    return 0;
}
