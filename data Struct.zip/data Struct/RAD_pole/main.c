#include <stdio.h>
#include <stdlib.h>

#define MAX 20

typedef struct{
    int val[MAX];
    int front, rear, size;
}RAD;

void ini(RAD *r){
    r->front = r->rear = r->size = 0;
}

void add(RAD *r, int val){
    if(r->size >= MAX){
        r->rear %= MAX;
        r->val[r->rear++] = val;
    }else{
        r->val[r->rear++] = val;
        r->rear %= MAX;
        r->size++;
    }
}

void pop(RAD *r){
    if(r->size > 0){
        r->front = (r->front+1)%MAX;
        r->size--;
    }
}

void print(RAD r){
    int cnt = 0;
    while(cnt < r.size){
        printf("%d ->", r.val[(r.front + cnt)%MAX]);
        cnt++;
    }
}

int main()
{
    RAD rad;
    ini(&rad);
    for(int i = 0; i < 25; i++)
        add(&rad, i);
    print(rad);
    return 0;
}
