#include <stdio.h>
#include <stdlib.h>

#define MAX 20

typedef struct stack{
    int val[MAX];
    int vert;
}STACK;

void ini(STACK *st){
    st->vert = 0;
}

void add(STACK *st, int val){
    if(st->vert < MAX){
        st->val[st->vert++] = val;
    }
}

void pop(STACK *st){
    if(st->vert > 0)
        st->vert--;
}

void print_stack(STACK st){
    for(int i = st.vert; i >= 0; i--){
        printf("%d->",st.val[i]);
    }
}

int main()
{
    STACK st;
    ini(&st);
    add(&st, 2);
    add(&st, 3);
    add(&st, 5);
    add(&st, 1);
    print_stack(st);

    return 0;
}
