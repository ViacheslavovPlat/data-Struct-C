#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next, *prev;
    int val;
}NODE;

typedef struct {
    NODE *start, *end, *index;
}LIST;

void ini(LIST *list){
    list->end = list->start = list->index = NULL;
}

int isEmpty(NODE *node){
    return node == NULL;
}

void add(LIST *list, int val){
    if(isEmpty(list->start)){
        list->start = ML;
        list->start->val = val;
        list->start->next = list->start;
        list->start->prev = list->start;
        list->end = list->index = list->start;
    }else{
        if(list->start->next == list->start){
            list->start->next = list->start->prev = ML;
            list->end = list->start->next;
            list->end->val = val;
            list->end->prev = list->start;
            list->end->next = list->start;
            list->index = list->end;
        }else if(list->index == list->end){
            list->end->next = ML;
            list->end->next->prev = list->end;
            list->end->next->next = list->start;
            list->end = list->end->next;
            list->end->val = val;
            list->start->prev = list->end;
            list->index = list->end;
        }else{
            NODE *tmp = ML;
            tmp->val = val;
            tmp->next = list->index->next;
            tmp->prev = list->index;
            list->index->next->prev = tmp;
            list->index->next = tmp;
            list->index = tmp;
        }
    }
}

void jmp_start(LIST *list){
    list->index = list->start;
}

void jmp_end(LIST *list){
    list->index = list->end;
}

void step_forward(LIST *list){
    list->index = list->index->next;
}

void step_backward(LIST *list){
    list->index = list->index->prev;
}

void show(LIST list){
    if(!isEmpty(list.start)){
        jmp_start(&list);
        do{
            printf("%d->", list.index->val);
            step_forward(&list);
        }while(list.index != list.start);
        printf("%d\n", list.index->val);
    }
}

void show_from_index(LIST list){
    if(isEmpty(list.start)){
        printf("NULL\n");
        return;
    }
    NODE *tmp = list.index;
    do{
        printf("%d->", list.index->val);
        step_forward(&list);
    }while(list.index != tmp);
    printf("%d\n", list.index->val);
}

void show_rev(LIST list){
    if(!isEmpty(list.start)){
        jmp_end(&list);
        do{
            printf("%d<-", list.index->val);
            step_backward(&list);
        }while(list.index != list.end);
        printf("%d\n", list.index->val);
    }
}

void pop(LIST *list){
    if(isEmpty(list->start))
        return;
    if(list->start->next == list->start){
        list->start = list->index = list->end = NULL;
    } else if(list->index == list->end){
        list->end = list->end->prev;
        list->end->next = list->start;
        list->start->prev = list->end;
        free(list->index);
        list->index = list->end;
    } else if(list->index == list->start) {
        list->start = list->start->next;
        list->start->prev = list->end;
        list->end->next = list->start;
        free(list->index);
        list->index = list->start;
    } else {
        NODE *tmp = list->index;
        list->index = list->index->next;
        tmp->prev->next = list->index;
        list->index->prev = tmp->prev;
        free(tmp);
    }
}

int main()
{
    LIST list;
    ini(&list);
    for(int i = 0; i < 15; i++)
        add(&list, i);

    jmp_end(&list);
    pop(&list);
    show(list);
    jmp_start(&list);
    pop(&list);
    show(list);
    step_forward(&list);
    step_forward(&list);
    pop(&list);
    show(list);
    show_rev(list);
    while(list.start){
        pop(&list);
        show(list);
    }
    return 0;
}
