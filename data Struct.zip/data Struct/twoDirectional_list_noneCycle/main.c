#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *prev, *next;
    int val;
}NODE;

typedef struct {
    NODE *node;
}LIST;

void ini(LIST *list){
    list->node = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add(LIST *list, int val){
    if(isEmpty(list->node)){
        list->node = ML;
        list->node->val = val;
        list->node->next = list->node->prev = NULL;
    } else {
        NODE *tmp = list->node;
        while(tmp->next){
            tmp = tmp->next;
        }
        tmp->next = ML;
        tmp->next->prev = tmp;
        tmp = tmp->next;
        tmp->val = val;
        tmp->next = NULL;
    }
}

void show_forward(LIST list){
    NODE *tmp = list.node;
    while(tmp){
        printf("%d->",tmp->val);
        tmp = tmp->next;
    }
    printf("NULL\n");
}

void show_backward(LIST list){
    NODE *tmp = list.node;
    while(tmp->next){
        tmp = tmp->next;
    }

    while(tmp){
        printf("%d<-",tmp->val);
        tmp = tmp->prev;
    }
    printf("NULL\n");
}

void pop(LIST *list){
    if(isEmpty(list->node->next)){
        list->node = NULL;
        free(list);
    }else{
        NODE *tmp = list->node;
        list->node = list->node->next;
        tmp = NULL;
        list->node->prev = NULL;
    }
}

int main()
{
    LIST list;
    ini(&list);
    for(int i = 0; i < 15; i++){
        add(&list, i);
        show_forward(list);
        show_backward(list);
    }

    for(int i = 0; i < 15; i++){
        pop(&list);
        show_forward(list);
        show_backward(list);
    }
    return 0;
}
