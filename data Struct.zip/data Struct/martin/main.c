#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 4
#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node* martin_signs[MAX];
    char word[7];
    char sign;
}NODE;

typedef struct {
    char slovo[5];
    char word[8];
}SC;

void ini(NODE **n, char sign){
    *n = ML;
    (*n)->sign = sign;
    for(int i = 0; i < MAX; i++){
        (*n)->martin_signs[i] = NULL;
    }
    strcpy((*n)->word, "");
}

int getIndex(char sign){
    switch(sign){
        case 'X':
            return 0;
        case '5':
            return 1;
        case 'r':
            return 2;
        case '#':
            return 3;
    }
}

void add(NODE **n, char slovo[], char word[]){
    int i = 0;
    NODE *tmp = *n;
    while(i < MAX){
        int index = getIndex(slovo[i]);
        if(!tmp->martin_signs[index]){
            ini(&(tmp->martin_signs[index]), slovo[i]);
        }
        tmp = tmp->martin_signs[index];
        i++;
    }
    strcpy(tmp->word, word);
}

void translate(NODE *trie, char slovo[]){
    for(int i = 0; i < MAX; i++){
        int index = getIndex(slovo[i]);
        if(trie->martin_signs[index])
            trie = trie->martin_signs[index];
        else{
            printf("no such word\n");
            return;
        }
    }
    printf("%s\n", trie->word);
}

int isEmpty(NODE *n){
    if(n==NULL)
        return 1;
    for(int i = 0; i < MAX; i++){
        if(n->martin_signs[i])
            return 0;
    }
    return 1;
}

void show(NODE *trie){
    if(!trie)
        return;
    if(isEmpty(trie)){
        printf("%s\n", trie->word);
        return;
    }
    for(int i = 0; i < MAX; i++){
        if(trie->martin_signs[i])
            show(trie->martin_signs[i]);
    }
    return;
}

void odstran(NODE **trie){
    if(!(*trie))
        return;

    for(int i = 0; i < MAX; i++){
        if((*trie)->martin_signs[i])
            odstran(&((*trie)->martin_signs[i]));
    }
    free(*trie);
    *trie = NULL;
}

int main()
{
    NODE *lexTree;
    ini(&lexTree, ' ');
    FILE *f = fopen("Slovnik.txt", "r");
    if(!f){
        fprintf(stderr, "couldn't open file\n");
        exit(-1);
    }
    SC sc;
    while(fscanf(f,"%s %s", sc.slovo, sc.word) == 2){
        add(&lexTree, sc.slovo, sc.word);
    }
    show(lexTree);
    odstran(&lexTree);
    if(lexTree == NULL)
        printf("URA");
    return 0;
}
