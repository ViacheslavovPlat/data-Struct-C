#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    int val;
    struct node *next;
}NODE;

typedef struct rad{
    NODE *front, *rear;
}RAD;

void ini_smer(RAD *r){
    r->front = r->rear = ML;
    r->rear->next = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add_smer(RAD *r, int val){
    r->rear->val = val;
    r->rear->next = ML;
    r->rear = r->rear->next;
    r->rear->next = NULL;
}

int pop_smer(RAD *r){
    if(!isEmpty(r->front)){
        NODE *tmp;
        tmp = r->front;
        r->front = r->front->next;
        printf("%d bola odstranena hodnota\n", tmp->val);
        free(tmp);
        return 1;
    }
    printf("failed\n");
    return 0;
}

void print(RAD r){
    while(r.front->next){
        printf("%d->\n", r.front->val);
        r.front = r.front->next;
    }
}

void ini_bez(RAD *r){
    r->rear = r->front = NULL;
}

void add_bez(RAD *r, int val){
    NODE *tmp = ML;
    tmp->val = val;
    tmp->next = NULL;

    if(isEmpty(r->front)){
        r->front = r->rear = tmp;
    } else {
        r->rear->next = tmp;
        r->rear = r->rear->next;
    }
}

void show(RAD r){
    while(r.front){
        printf("%d->", r.front->val);
        r.front = r.front->next;
    }
}

int pop_bez(RAD *r){
    if(!isEmpty(r->front)){
        NODE* tmp = r->front;
        r->front = r->front->next;
        free(tmp);
    }
}

int main()
{
    RAD rad;
    ini_bez(&rad);

    for(int i = 0; i < 10; i++)
        add_bez(&rad, i);

    show(rad);
    pop_bez(&rad);
    show(rad);
    return 0;
}
