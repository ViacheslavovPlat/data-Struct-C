#include <stdio.h>
#include <stdlib.h>

#define ML (STACK*)malloc(sizeof(STACK))

typedef struct stack{
    struct stack* next;
    int val;
}STACK;

void ini(STACK **st){
    *st = ML;
    (*st)->next = NULL;
}

void add(STACK **st, int val){
    STACK *tmp = ML;
    tmp->val = val;
    tmp->next = *st;
    *st = tmp;
}

void pop(STACK **st){
    if(st){
        STACK *tmp = *st;
        *st = (*st)->next;
        free(tmp);
    }
}

void print_stack(STACK *st){
    if(st){
        do{
            printf("%d -> ", st->val);
            st = st->next;
        }while(st);
    }
}

int main()
{
    STACK *st;
    ini(&st);
    add(&st,5);
    add(&st,1);
    add(&st,2);
    add(&st,3);
    pop(&st);
    print_stack(st);
    return 0;
}
