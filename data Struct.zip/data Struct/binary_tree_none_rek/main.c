#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *right, *left;
    int val;
}NODE;

typedef struct {
    NODE *node;
}BST;

void ini(BST *bst){
    bst->node = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add_none_rek(BST *bst, int val){
    NODE *tmp = bst->node;
    NODE *pre_tmp;
    if(isEmpty(bst->node)){
        bst->node = ML;
        bst->node->val = val;
        bst->node->left = bst->node->right = NULL;
    }else {
        while(tmp){
            pre_tmp = tmp;
            if(tmp->val > val){
                tmp = tmp->left;
            }else{
                tmp = tmp->right;
            }
        }
        tmp = ML;
        tmp->left = tmp->right = NULL;
        tmp->val = val;
        if(pre_tmp->val > val){
            pre_tmp->left = tmp;
        } else {
            pre_tmp->right = tmp;
        }
    }
}

void show_preorder(NODE *node){
    if(!node)
        return;
    printf("%d->", node->val);
    show_preorder(node->left);
    show_preorder(node->right);
}

void show_inorder(NODE *node){
    if(!node)
        return;
    show_inorder(node->left);
    printf("%d->", node->val);
    show_inorder(node->right);
}

void post_order(NODE *node){
    if(!node)
        return;
    post_order(node->left);
    post_order(node->right);
    printf("%d->", node->val);
}

int main()
{
    BST bst;
    ini(&bst);
    for(int i = 7; i < 15 ;i++){
        add_none_rek(&bst, i);
    }
    for(int i = 7; i > 0; i--){
        add_none_rek(&bst, i);
    }

    show_inorder(bst.node);
    printf("\n");
    show_preorder(bst.node);
    printf("\n");
    post_order(bst.node);
    printf("\n");
    return 0;
}
