#include <stdio.h>
#include <stdlib.h>

#define ML (STACK*)malloc(sizeof(STACK))

typedef struct stack{
    struct stack *next;
    char zat;
}STACK;

void ini(STACK **s){
    *s = NULL;
}

void add(STACK **r, char val){
    STACK *new_node = ML;
    new_node->zat = val;
    new_node->next = *r;
    *r = new_node;
}

char pop(STACK **r){
    if(*r == NULL)return;
    STACK *tmp = *r;
    (*r) = (*r)->next;
    char val = tmp->zat;
    free(tmp);
    return val;
}

void reverse_str(char *str){
    STACK *rev_str = NULL;
    for(int i = 0; i < strlen(str); i++)
        add(&rev_str,str[i]);
    char c;
    while(rev_str != NULL){
        c = pop(&rev_str);
        putc(c,stdout);
    }
}

int controlPrentacies(STACK **r, const char *str){

    for(int i = 0; i < strlen(str); i++){
        switch(str[i]){
            case '(':
                add(&r, ')');
                continue;
            case '{':
                add(&r, '}');
                continue;
            case '[':
                add(&r, ']');
                continue;
            case ')':
            case ']':
            case '}':
                if(*r == NULL){
                    printf("extra closing brakets!\n");
                    return 0;
                }
                char poped = pop(&r);
                if(poped != str[i]){
                    printf("missing closing braket expected %c but popped %c!\n", str[i], poped);
                    return 0;
                }
                continue;
            default:
                continue;
        }
    }
    if(*r != NULL){
        printf("missing closing brakets!\n");
        while(*r)
            pop(&(*r));
        *r = NULL;
        return 0;
    }

    *r = NULL;

    return 1;
}


int main()
{
    STACK *r;

    ini(&r);
    char buff[100];
    fgets(buff, 100, stdin);
    buff[strcspn(buff,"\n")] = '\0';
    /*if(!controlPrentacies(&r,buff))
        printf("Zadali ste chybu!\n");
    else
        printf("Super!\n");
    */
    reverse_str(buff);
    return 0;
}
