#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next;
    int val;
}NODE;

typedef struct{
    NODE *node;
}LIST;

void ini(LIST *list){
    list->node = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add(LIST *list, int val){
    if(isEmpty(list->node)){
        list->node = ML;
        list->node->val = val;
        list->node->next = list->node;
    }else if(list->node->next == list->node){
        list->node->next = ML;
        list->node->next->val = val;
        list->node->next->next = list->node;
    }else{
        NODE *tmp = list->node;
        while(tmp->next != list->node){
            tmp = tmp->next;
        }
        tmp->next = ML;
        tmp = tmp->next;
        tmp->val = val;
        tmp->next = list->node;
    }
}

void show(LIST list){
    NODE *index = list.node;
    do{
        printf("%d->", index->val);
        index = index->next;
    }while(index != list.node);
    printf("%d", index->val);
    printf("\n");
}

void pop(LIST *list){
    if(!isEmpty(list->node)){
        if(list->node->next == list->node){
            list->node = NULL;
            free(list);
        } else {
            NODE *tmp = list->node;
            while(tmp->next != list->node){
                tmp = tmp->next;
            }
            tmp->next = list->node->next;
            tmp = list->node;
            list->node = list->node->next;
            free(tmp);
        }
    }
}

int main()
{
    LIST list;
    ini(&list);
    add(&list,5);
    show(list);
    add(&list,3);
    show(list);
    add(&list,2);
    show(list);
    add(&list,1);
    show(list);

    pop(&list);
    show(list);
    pop(&list);
    show(list);
    pop(&list);
    show(list);
    pop(&list);
    show(list);
    return 0;
}
