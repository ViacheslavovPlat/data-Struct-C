#include <stdio.h>
#include <stdlib.h>

#define ML (NODE*)malloc(sizeof(NODE))

typedef struct node{
    struct node *next, *prev;
    int val;
}NODE;

typedef struct{
    NODE *node;
}LIST;

void ini(LIST *l){
    l->node = NULL;
}

int isEmpty(NODE *n){
    return n == NULL;
}

void add(LIST *list, int val){
    if(isEmpty(list->node)){
        list->node = ML;
        list->node->val = val;
        list->node->next = list->node;
        list->node->prev = list->node;
    }else if(list->node->next == list->node){
        NODE *tmp = ML;
        tmp->val = val;
        list->node->next = tmp;
        list->node->prev = tmp;
        tmp->next = list->node;
        tmp->prev = list->node;
    }else{
        NODE *index = list->node;
        while(index->next != list->node){
            index = index->next;
        }
        index->next = ML;
        index->next->prev = index;
        index = index->next;
        index->val = val;
        index->next = list->node;
        list->node->prev = index;
    }
}

void show_forward(LIST list){
    NODE *tmp = list.node;
    do{
        printf("%d->", tmp->val);
        tmp = tmp->next;
    }while(tmp != list.node);
    printf("st:%d\n",tmp->val);
}

void show_backwrad(LIST list){
    NODE *tmp = list.node;
    do{
        printf("%d->", tmp->val);
        tmp = tmp->prev;
    }while(tmp != list.node);
    printf("st:%d\n", tmp->val);
}

void pop(LIST *list){
    if(list->node->next == list->node){
        list->node = NULL;
        free(list);
        return;
    }else{
        NODE *tmp = list->node->prev;
        tmp->next = list->node->next;
        list->node->next->prev = tmp;
        tmp = list->node;
        list->node = list->node->next;
        free(tmp);
    }
}

int main()
{
    LIST list;
    ini(&list);
    for(int i = 0; i < 15; i++)
        add(&list, i);

    show_forward(list);
    show_backwrad(list);
    for(int i = 0; i < 15; i++){
        pop(&list);
        show_forward(list);
    }
    return 0;
}
