#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define ELEM_COUNT 12
#define FI 0.6180339887
#define ML (SC*)malloc(sizeof(SC))

typedef struct {
    char name[20];
    char surname[20];
    int val;
    float fval;
}SC;

int getHashTabSize(int n){
    n += (int)(n/3);
    while(!isPrime(n))
        n++;
    return n;
}

int isPrime(int n){
    if(n == 1 || n == 0)
        return 0;
    int lim = sqrt(n);
    for(int i = 2; i <= lim; i++){
        if(n % i == 0)
            return 0;
    }
    return 1;
}

int FloatHash(float n){
    float min = 0, max = 100;
    return ceil(((n - min)/(max - min)) * (getHashTabSize(ELEM_COUNT)-1));
}

int IntHash1(int n){
    float min = 22 , max = 35;
    return ceil((n-min)/(max-min) * (getHashTabSize(ELEM_COUNT)- 1));
}

int IntHash2(int n){
    float max = 35;
    int w = 1;

    while(w < max)
        w <<= 1;
    return ceil((n/(float)w) * (getHashTabSize(ELEM_COUNT) - 1));
}

int IntHash3(int n){
    float pom = n * FI;
    pom -=(int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT)-1));
}

int IntHash4(int n){
    return n % getHashTabSize(ELEM_COUNT);
}

int StrHash1(char *str){
    //'a' = 97 1100001 'A' = 65 1000001 & 00011111
    long long int x = 0;
    int c , i = 1;
    x = str[0] & 31;
    while(str[i] != '\0'){
        x <<= 5;
        c = str[i] & 31;
        x |= c;
        i++;
    }

    long double pom = x * FI;
    pom -=(long long int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT)-1));
}

int StrHash2(char *str){
    int x = 0;
    int c, i = 1;
    x = str[0] & 31;
    while(str[i] != '\0'){
        c = str[i] & 31;
        x = x ^ c;
        i++;
    }
    float pom = x * FI;
    pom -=(int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT) -1));
}

int StrHash3(char *str){
    long long x = 0;
    int i = 1, c;
    x = str[0] & 31;
    while(str[i] != '\0'){
        x <<=1;
        c = str[i] & 31;
        x ^= c;
        i++;
    }
    float pom = x * FI;
    pom -=(long long int)pom;
    return ceil(pom * (getHashTabSize(ELEM_COUNT) - 1));
}

int main()
{
    FILE *f = fopen("sample_data.txt", "r");
    SC sc;
    int tab_size = getHashTabSize(ELEM_COUNT);
    SC *hashTable[tab_size];
    int i = 0;
    while(i < tab_size)
        hashTable[i++] = NULL;

    while(fscanf(f,"%s %s %d %f", sc.name, sc.surname, &sc.val, &sc.fval) == 4){
        //printf("%s->#STR:%d %s->#STR:%d %d->#INT:%d %.2f->#F:%d\n", sc.name, StrHash1(sc.name), sc.surname, StrHash1(sc.surname),sc.val, IntHash4(sc.val), sc.fval, FloatHash(sc.fval));
        int pos = StrHash1(sc.name);
        printf("%s %s %d %.2f ->#STR:%d\n", sc.name, sc.surname, sc.val, sc.fval, pos);

        if(hashTable[pos]){
            int tmp = pos;
            ///Linearna Sondaz
            /*do{
                pos = (pos+1)%tab_size;
            }while((hashTable[pos]) && tmp != pos);
            if(tmp == pos)
                continue;*/
            ///Dvojite hashovanie
            int step = StrHash2(sc.name);
            do{
                pos = (pos+step) % tab_size;
            }while(hashTable[pos] && tmp != pos);
            if(tmp == pos)
                continue;
        }
        hashTable[pos] = ML;
        hashTable[pos]->fval = sc.fval;
        hashTable[pos]->val = sc.val;
        strcpy(hashTable[pos]->name,sc.name);
        strcpy(hashTable[pos]->surname,sc.surname);
    }
    fclose(f);

    char *str = "Mark";
    int hash = StrHash1(str);
    int krok = StrHash2(str);
    if(strcmp(hashTable[hash]->name, str)==0){
        printf("nasiel si %s za originalnou hashou\n", hashTable[hash]->name);
    }else{
        int tmp_pos = hash;
        do{
            hash = (hash+krok) % tab_size;
        }while(strcmp(hashTable[hash]->name,str) != 0 && tmp_pos != hash);
        if(hash == tmp_pos){
            printf("taky to v tab neni\n");
        }else{
            printf("nasiel si %s za hashou %d\n", hashTable[hash]->name, hash);
        }
    }

    for(i = 0; i < tab_size; i++){
        printf("hash [%d] %s %s\n", i, hashTable[i]->name, hashTable[i]->surname);
    }

    return 0;
}
